function [VarQC] = SmoothQC(Var,span,P)
%%% This function finds and deletes the outliers in time series by difference threshold between original var and smoothed var
% Var: The time series to be operated
% span: Window of smooth(Number of data points for calculating the smoothed value )
% P:Percent of threshold diff(var).

diffVar = diff(Var);
diffVar(isnan(diffVar))=[];
diffVarSort = sortrows(abs(diffVar));
n = length(diffVarSort);


diffVarP = diffVarSort(round(n*P));

SmoothedVar = smooth(Var,span);

dVar = abs(Var - SmoothedVar);

indOut = find(dVar > diffVarP);

VarQC = Var;
VarQC(indOut) = NaN;

